# Claude Code 对话存档 — 2026-04-19

- 总 transcript 数：17
- 真实用户会话（user messages > 1）：17
- Headless 子会话（`claude -p` 调用）：0  （已包含）

## 目录

| 路径 | 说明 |
|------|------|
| `jsonl/`     | Claude Code 原始 JSONL transcript，每行一个事件（user/assistant/tool_use/tool_result/thinking）|
| `markdown/`  | 可读 Markdown，仅保留 user/assistant 的 text 块（不含 tool_use 细节、thinking）|
| `summary.txt`| 所有 session 的索引：日期、时间、session_id、首条用户消息 |

## 项目列表

- `-home-user-ClaudeCode`

## 源路径

`/root/.claude/projects`

## 无法本地导出的部分

以下数据不存在于本地，需要手动从 Anthropic 账户导出：

- **claude.ai 网页版对话**
- **Claude 桌面 app 对话**

操作路径（桌面/网页共用同一账户）：

1. 登录 https://claude.ai
2. Settings → Privacy → **Export data**
3. 点击"Export"，Anthropic 会把你账户下所有对话打成 ZIP 发邮件（几分钟到几小时）
4. 下载后解压，每个对话是一个 JSON，里面有完整 messages

如果只要导出**单个对话**：在该对话页面右上角 "..." → "Export chat" → 下载 Markdown/JSON。
